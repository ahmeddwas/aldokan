
# الدكان - Aldokan

مشروع Jetpack Compose يشتغل من اندرويد 5 الى 16

## كيف تفحص البناء الحقيقي؟

1. اعمل repository جديد في GitHub
2. ارفع هذا المجلد كامل
3. روح تبويب Actions - بتشوف البناء شغال
4. اذا نجح، بيعطيك APK جاهز تحمله من Artifacts
5. اذا فشل، بيطلع لك اللوج بالضبط فين الخطأ (generateSourcesRelease)

هذا هو الفحص الحقيقي بـ Gradle اللي طلبته.

## البناء في CodeAssist

افتح المجلد في CodeAssist واضغط Run - بيبني مباشرة بدون الحاجة لـ GitHub.
