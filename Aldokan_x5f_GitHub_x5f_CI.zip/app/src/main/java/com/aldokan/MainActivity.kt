
package com.aldokan

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

// DBHelper خفيف بدون Room - يحل مشكلة generateSourcesRelease
class DBHelper(context: Context) : SQLiteOpenHelper(context, "aldokan.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, debt INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE trans(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER, amount INTEGER, date INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {}
    fun getCustomers(): List<Triple<Long, String, Long>> {
        val list = mutableListOf<Triple<Long, String, Long>>()
        val c = readableDatabase.rawQuery("SELECT id, name, debt FROM customers ORDER BY debt DESC", null)
        while (c.moveToNext()) list.add(Triple(c.getLong(0), c.getString(1), c.getLong(2)))
        c.close(); return list
    }
    fun getTotal(): Long {
        val c = readableDatabase.rawQuery("SELECT SUM(debt) FROM customers", null)
        var t = 0L; if (c.moveToFirst()) t = c.getLong(0); c.close(); return t
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dbHelper = DBHelper(this)
        setContent {
            MaterialTheme {
                var customers by remember { mutableStateOf(dbHelper.getCustomers()) }
                var total by remember { mutableStateOf(dbHelper.getTotal()) }
                var selectedId by remember { mutableStateOf<Long?>(null) }
                var selectedName by remember { mutableStateOf("") }
                var showAddCustomer by remember { mutableStateOf(false) }
                var showAddTrans by remember { mutableStateOf(false) }
                var transList by remember { mutableStateOf(listOf<Pair<Long, Long>>()) } // amount, date
                val context = LocalContext.current

                fun refresh() {
                    customers = dbHelper.getCustomers()
                    total = dbHelper.getTotal()
                    selectedId?.let { id ->
                        val c = dbHelper.readableDatabase.rawQuery("SELECT amount, date FROM trans WHERE customerId=? ORDER BY date DESC", arrayOf(id.toString()))
                        val l = mutableListOf<Pair<Long, Long>>()
                        while (c.moveToNext()) l.add(Pair(c.getLong(0), c.getLong(1)))
                        c.close()
                        transList = l
                    }
                }

                Scaffold(
                    topBar = { TopAppBar(title = { Text(if (selectedId == null) "الدكان - Compose" else selectedName) }) },
                    floatingActionButton = {
                        if (selectedId == null) {
                            FloatingActionButton(onClick = { showAddCustomer = true }) { Text("+") }
                        } else {
                            FloatingActionButton(onClick = { showAddTrans = true }) { Text("دين") }
                        }
                    }
                ) { padding ->
                    Column(Modifier.padding(padding).padding(16.dp)) {
                        if (selectedId == null) {
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("إجمالي الديون")
                                    Text("$total ريال", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            LazyColumn {
                                items(customers) { (id, name, debt) ->
                                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = {
                                        selectedId = id; selectedName = name; refresh()
                                    }) {
                                        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(name, fontWeight = FontWeight.Bold)
                                            Text("$debt ريال", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        } else {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Button(onClick = { selectedId = null; refresh() }) { Text("رجوع") }
                                Button(onClick = {
                                    val msg = "كشف حسابك عند البقالة\nالمتبقي عليك: ${customers.find { it.first == selectedId }?.third ?: 0} ريال"
                                    val db = dbHelper.readableDatabase
                                    val cur = db.rawQuery("SELECT phone FROM customers WHERE id=?", arrayOf(selectedId.toString()))
                                    var phone = ""
                                    if (cur.moveToFirst()) phone = cur.getString(0)
                                    cur.close()
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/967$phone?text=${Uri.encode(msg)}"))
                                    context.startActivity(intent)
                                }) { Text("واتساب للزبون") }
                            }
                            LazyColumn {
                                items(transList) { (amount, date) ->
                                    val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
                                    Card(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(if (amount > 0) "دين $amount" else "تسديد ${-amount}")
                                            Text(sdf.format(Date(date)))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (showAddCustomer) {
                        var name by remember { mutableStateOf("") }
                        var phone by remember { mutableStateOf("") }
                        AlertDialog(onDismissRequest = { showAddCustomer = false }, title = { Text("زبون جديد") },
                            text = {
                                Column {
                                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") })
                                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("رقم 77xxxxxxx") })
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    val db = dbHelper.writableDatabase
                                    val cv = ContentValues()
                                    cv.put("name", name); cv.put("phone", phone)
                                    db.insert("customers", null, cv)
                                    showAddCustomer = false; refresh()
                                }) { Text("حفظ") }
                            }
                        )
                    }

                    if (showAddTrans) {
                        var amount by remember { mutableStateOf("") }
                        var isDebt by remember { mutableStateOf(true) }
                        AlertDialog(onDismissRequest = { showAddTrans = false }, title = { Text("عملية جديدة") },
                            text = {
                                Column {
                                    OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("المبلغ") })
                                    Row {
                                        FilterChip(selected = isDebt, onClick = { isDebt = true }, label = { Text("دين") })
                                        Spacer(Modifier.width(8.dp))
                                        FilterChip(selected = !isDebt, onClick = { isDebt = false }, label = { Text("تسديد") })
                                    }
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    var amt = amount.toLongOrNull() ?: 0L
                                    if (!isDebt) amt = -amt
                                    val db = dbHelper.writableDatabase
                                    val cv = ContentValues()
                                    cv.put("customerId", selectedId)
                                    cv.put("amount", amt)
                                    cv.put("date", System.currentTimeMillis())
                                    db.insert("trans", null, cv)
                                    db.execSQL("UPDATE customers SET debt = debt + ? WHERE id = ?", arrayOf(amt, selectedId))
                                    showAddTrans = false; refresh()
                                }) { Text("حفظ") }
                            }
                        )
                    }
                }
            }
        }
    }
}
